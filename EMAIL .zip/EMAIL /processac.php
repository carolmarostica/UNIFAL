		<?php
			include_once 'evento.class.php';
			include_once 'conexao.class.php';
		
			$class = $_POST["txtClass"];
			$nome = $_POST["txtNome"];	
		
			$eventos = new evento($nome,$class);
			$MySQL = new MySQL;
			$MySQL->inserirevento($eventos->getNome(), $eventos->getClass());
			echo "Dados gravados com sucesso <br>";

			}
		?>


