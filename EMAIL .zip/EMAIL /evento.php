<!-- Conteudo -->
<div class="conteudo">
	<?php
		require_once 'init.php';
		$PDO = db_connect();
		$sql_count = "SELECT COUNT(*) AS total FROM evento ORDER BY nome ASC";
		$sql = "SELECT id, nome, class FROM evento ORDER BY nome ASC";
 
		$stmt_count = $PDO->prepare($sql_count);
		$stmt_count->execute();
		$total = $stmt_count->fetchColumn();
 
		$stmt= $PDO->prepare($sql);
		$stmt->execute();
	?>
	<h2>Lista de Evento</h2>
	<p>Total de Evento: <?php echo $total ?></p>
	<?php if($total > 0): ?>
	<table width="100%" border="1"> 
		<thead>			
			<tr>
				<th>Nome</th>
				<th>Classificacao</th>
			</tr>
		</thead>
		<tbody>
			<?php while($evento = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
			<tr>
				<td><?php echo $evento['nome'] ?></td>
				<td><?php echo $evento['class'] ?></td>
				
			</tr>
			<?php endwhile; ?>
 		</tbody>
	</table>
 	<?php else: ?>
 	<p> Nenhum Evento registrado </p>
 	<?php endif; ?>
 	<br>
 	<a href="form-addc.php">oi</a>
</div>
