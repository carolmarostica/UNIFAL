<!-- Conteudo -->
<div class="conteudo">
<?php
	require_once 'init.php';
	include_once 'pessoa.class.php';
	
	 // pega os dados do formulário
	 $nomep = isset($_POST['txtNomeP']) ? $_POST['txtNomeP'] : null;
	 $classp = isset($_POST['txtClassP']) ? $_POST['txtClassP'] : null;		 
	 
	 
 	if ( empty($nomep) || empty($classp)){
		
		header('Location:index.php');		
		exit;
	}

	 // instancia objeto cliente
	 $pessoas = new pessoa($nomep, $classp);
	
	 
	 // insere no BD
	 $PDO = db_connect();
	 $sql ="INSERT INTO pessoa(nomep, classp) VALUES(:nomep, :classp)";
	 $stmt = $PDO->prepare($sql);
	 $stmt->bindParam( ':nomep' , $nomep);
	 $stmt->bindParam( ':classp' , $classp);

	 if($stmt->execute())
	 {
		header('Location:index.php');
		
	 }
	 else
	 {
		 echo"Erro ao cadastrar evento.";
		 print_r($stmt->errorInfo());
		  echo "Mailer Error: " . $mail->ErrorInfo;
	 }
?>
</div>
