		<?php
			include_once 'pessoa.class.php';
			include_once 'conexao.class.php';
		
			$classp = $_POST["txtClassP"];
			$nomep = $_POST["txtNomeP"];	
		
			$pessoas = new pessoa($nomep,$classp);
			$MySQL = new MySQL;
			$MySQL->inserirpessoa($pessoas->getNomeP(), $pessoas->getClassP());
			echo "Dados gravados com sucesso <br>";

			}
		?>


