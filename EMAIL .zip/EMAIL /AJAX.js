$(document).ready(function(e){
function chama(botao) {
		var href = $(botao).attr('href');
		$(".conteudo").load(href + " .conteudo");
}

