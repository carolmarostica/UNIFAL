<?php 
	class evento{
		//decarando variaveis//
		private $nome;
		private $class;

		//construtor//
		public function __construct($nome, $class){
			$this->setNome($nome);
			$this->setClass($class);
		}
		//pega e entrega NOME//
		public function setNome($nome){
			$this->nome = $nome;
		}
		public function getNome(){
			return $this->nome;
		}
		
		//pega e entrega CLASSIFICACAO//
		public function setClass($class){
			$this->class= $class;
		}
		public function getClass(){
			return $this->class;
		}
	}

?>
