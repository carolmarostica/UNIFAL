<!-- Conteudo -->
<div class="conteudo">
<?php
	require_once 'init.php';
	include_once 'evento.class.php';
	
	 // pega os dados do formulário
	 $nome = isset($_POST['txtNome']) ? $_POST['txtNome'] : null;
	 $class = isset($_POST['txtClass']) ? $_POST['txtClass'] : null;
	 
 	if ( empty($nome) || empty($class)){
		
		header('Location:index.php');		
		exit;
	}

	 // instancia objeto cliente
	 $eventos = new evento($nome, $class);
	
	 
	 // insere no BD
	 $PDO = db_connect();
	 $sql ="INSERT INTO evento(nome, class) VALUES(:nome, :class)";
	 $stmt = $PDO->prepare($sql);
	 $stmt->bindParam( ':nome' , $nome);
	 $stmt->bindParam( ':class' , $class);

	date_default_timezone_set('Etc/UTC');
	require 'PHPMailer-master/PHPMailerAutoload.php';
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Debugoutput = 'html';
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 587;
	$mail->SMTPSecure = 'tls';
	$mail->SMTPAuth = true;

	//Username
	$mail->Username = "carolsmarostica@gmail.com";
	//Password
	$mail->Password = "Carol2014";

	//Enviador
	$mail->setFrom('carolsmarostica@gmail.com', 'PETBice');
	//Recebedor
	$mail->addAddress('carolcefet99@gmail.com', 'Parceiro PET');

	//Assunto
	$mail->Subject = 'Novo Evento de seu interesse!';
	//Corpo do email
	$mail->msgHTML("Foi adicionado um novo evento de seu interesse. Acesse nosso site para mais informações!");

	 if($stmt->execute() && $mail->send() )
	 {
		header('Location:evento.php');
		
	 }
	 else
	 {
		 echo"Erro ao cadastrar evento.";
		 print_r($stmt->errorInfo());
		  echo "Mailer Error: " . $mail->ErrorInfo;
	 }
?>
</div>
