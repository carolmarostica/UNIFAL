	<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap e Pingendo-->
	<link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
   <!-- <script type="text/javascript" src="bootstrap.min.js"></script> -->
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- JQuery -->
     <script type="text/javascript" src="jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="jquery-ui.js"></script>
	 <!-- <script type = "text/javascript" src = "jquery-1.8.2.js"></script> --> 
	<link rel="stylesheet" href="jquery-ui.css">
  <!-- <script type = "text/javascript" src = "datepicker-pt-BR.js"></script> -->
	<!-- Estilização -->
	<script  type="text/javascript"src="AJAX.js"></script>
	<link href="trab.css" rel="stylesheet" type="text/css">
	<!-- DatePicker -->
	<script  type="text/javascript"src="data.js"></script>
	
</head><body>
	<form method="post" action="addp.php" name="formCadastro" enctype="multipart/form-data">
		<h1>Cadastro de evento</h1>
		<table width="100%">
			<tr>
				<th width="18%">Nome</th>
				<td width="82%"><input type="text" name="txtNome"></td>
			</tr>				
			<tr>
				<input type="checkbox" name="txtClassP[]" value="pesquisa">Pesquisa<br></input>
			</tr>
			<tr>
				<input type="checkbox" name="txtClassP[]" value="entretenimento">Entretenimento<br></input>
			</tr>
			<tr>
				<input type="checkbox" name="txtClassP[]" value="ensino">Ensino<br></input>
			</tr>
			<tr>
				<input type="checkbox" name="txtClassP[]" value="extensao">Extensão<br></input>
			</tr>
			<tr>
				<input type="checkbox" name="txtClassP[]" value="outros">Outros</input>
			</tr>
			<tr></tr>
			<tr>
				<td></td>				
				<td>
					<input type="submit" href="addp.php" onclick="chama(this)" value="Cadastrar"></input>
					<input type="reset" name="bntLimpar" value="Limpar"></input>
				</td>
			</tr>
		</table>
	</form>
</div>
</body>
</html>
