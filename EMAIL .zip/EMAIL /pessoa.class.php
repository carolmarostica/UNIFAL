<?php 
	class pessoa{
		//decarando variaveis//
		private $nomep;
		private $classp;
		

		//construtor//
		public function __construct($nomep, $classp){
			$this->setNomeP($nomep);
			$this->setClassP($classp);
		}
		//pega e entrega NOME//
		public function setNomeP($nomep){
			$this->nomep = $nomep;
		}
		public function getNomeP(){
			return $this->nomep;
		}
		
		//pega e entrega CLASSIFICACAO//
		public function setClassP($classp){
			$this->classp= $classp;
		}
		public function getClassP(){
			return $this->classp;
		}
	}

?>
