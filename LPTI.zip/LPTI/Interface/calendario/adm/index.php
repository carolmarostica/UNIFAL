<!--Carolinha Silva Maróstica e Larissa Mendes Silvério-->
<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap e Pingendo-->
	<link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
   <!-- <script type="text/javascript" src="bootstrap.min.js"></script> -->
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- JQuery -->
     <script type="text/javascript" src="jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="jquery-ui.js"></script>
	 <!-- <script type = "text/javascript" src = "jquery-1.8.2.js"></script> --> 
	<link rel="stylesheet" href="jquery-ui.css">
  <!-- <script type = "text/javascript" src = "datepicker-pt-BR.js"></script> -->
	<!-- Estilização -->
	<script  type="text/javascript"src="assets/js/AJAX.js"></script>
	<link href="trab.css" rel="stylesheet" type="text/css">
	<!-- DatePicker -->
	<script  type="text/javascript"src="data.js"></script>
	
</head><body>
	
	<!-- Conteudo -->
		<a href="evento.php">CLIENTES</a>

</body></html>
