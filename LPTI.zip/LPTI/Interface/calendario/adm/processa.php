		<?php
			include_once 'evento.class.php';
			

			//Verifica nome//
			$tema = $_POST['txtTema'];  
			$local = $_POST['txtLocal'];
			$palestrante = $_POST['txtPalestrante'];
			$horario = $_POST['horario'];
			$data =$_POST['txtData'];	
			$descricao = $_POST['txtDescricao'];
			$classificacao =$_POST['txtClassificacao'];   

           if($tema == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
            }else{
					$camposOK = TRUE;
			}
			
            if($local == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
            }else{
					$camposOK = TRUE;
			}
			
            if($palestrante == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
            }else{
					$camposOK = TRUE;
			}
			
            if($horario == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
            }else{
					$camposOK = TRUE;
			}
			
            if($data == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
            }else{
					$camposOK = TRUE;
			}
			
            if($descricao == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
            }else{
					$camposOK = TRUE;
			}
			
            if($classificacao == null){
                     echo("O campo primeiro nome deve ser preenchido!");                   
			}else{
					$camposOK = TRUE;
			}          
      			
		/*	//Valida data//
			if (($data[2] <= 2016) && ($data[2]>0000)){				
				if (($data[1] == 04) || ($data[1] == 06)  || ($data[1] == 09) || ($data[1] == 11)){
					if(($data[0] <= 30) && ($data[0] > 00)){	
					}else{	
						$camposOK = false;
					}
				} else if (($data[1] == 01) || ($data[1] == 03)  || ($data[1] == 05) || ($data[1] == 07) || ($data[1] == 08)|| ($data[1] == 10)|| ($data[1] == 12) ){
					if(($data[0] <= 31) && ($data[0] > 00)){	
					}else{	
						$camposOK = false;
					}
				}else if ($data[1] == 02){
					if ($data[2] % 4 ==0){
						if ($data[2] % 100 !=0){
							if ($data[0] <= 29){
							} else if ($data[2] % 400 ==0){
									if (($data[0] <= 29) && ($data[0] > 00)){						
									}else{	
										$camposOK = false;
									}
							} else if (($data[0] <= 28) && ($data[0] > 00)){
								}else{
									$camposOK = false;
								}
						}else{
							$camposOK = false;
						}
					}else{
						echo "A data está inválida <br>";
						$camposOK = false;
					}
				}
			}
			
			*/	
			//Escrever tudo
			if( $camposOK ){
				$evento = new Evento($data, $local, $palestrante, $horario, $tema, $descricao, $classificacao);
				$MySQL = new MySQL;
				
				try{
					$MySQL->inserirEvento($evento->getNomeCliente(), $evento->getDataCadastro(), $evento->getEmail());
					echo "Dados gravados com sucesso <br>";
				}catch (Exception $email){
					echo "Erro ao inserir: ". $email->getMessage() . "<br>" ;
				}
			}
		?>


