
$(document).ready(function() {


$('#calendar').fullCalendar({
    events: 'MC.php'
});
  });

