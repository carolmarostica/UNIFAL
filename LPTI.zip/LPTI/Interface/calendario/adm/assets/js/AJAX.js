$(document).ready(function(e){
	$("#teste").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$(".row").load(href + " .row");
	});
});

function chama(botao) {
		var href = $(botao).attr('href');
		$(".row").load(href + " .row");
}

