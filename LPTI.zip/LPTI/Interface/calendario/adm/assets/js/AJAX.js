$(document).ready(function(e){
	$("#vere").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudo").load(href + " #conteudo");
	});
	$("#verp").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudo").load(href + " #conteudo");
	});
	$("#verm").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudo").load(href + " #conteudo");
	});
	$("#vern").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudo").load(href + " #conteudo");
	});
	
});

function chama(botao) {
	var href = $(this).attr('href');
	$(".conteudo").load(href + " .conteudo");
	
}
