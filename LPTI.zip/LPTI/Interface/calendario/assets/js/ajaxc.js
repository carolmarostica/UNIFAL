$(document).ready(function() {
    $('#calendar').fullCalendar({
		events:[
			{
				title : 'evento4',
				start : '2016-08-24',
				color : '#ebccd1' ,
				textColor : '#a94442'  
			},
			{
				title : 'evento3',
				start : '2016-08-18',
				color : '#faebcc',
				textColor : '#8a6d3b'   
			},
			{
				title : 'evento2',
				start : '2016-08-19',  
				color : '#d6e9c6',
				textColor : '#3c763d'
			}
		]
	});
  });
