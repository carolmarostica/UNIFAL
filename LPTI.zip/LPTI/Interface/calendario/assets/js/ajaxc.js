
$(document).ready(function() {

$('#calendar').fullCalendar({
    events:'MC.php',
 eventClick: function(calEvent, jsEvent, view) {

        alert('Titulo: ' + calEvent.title);

        // mostrar qual ele selecionou
        $(this).css('border-color', 'red');

    }
});

$('#calendarioADM').fullCalendar({
 events: '../MC.php',
 eventClick: function(calEvent, jsEvent, view) {

        alert('Titulo: ' + calEvent.title );
        

        // mostrar qual ele selecionou
        $(this).css('border-color', 'red');

    }
 });
 });



