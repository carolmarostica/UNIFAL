$(document).ready(function() {
    $('#calendar').fullCalendar({
		events:[
			{
				title : 'Interclasse',
				start : '2016-09-24',
				color : '#ebccd1' ,
				textColor : '#a94442'  
			},
			{
				title : 'Cotas',
				start : '2016-09-04',
				color : '#faebcc',
				textColor : '#8a6d3b'   
			},
			{
				title : 'Linux',
				start : '2016-09-27',  
				color : '#d6e9c6',
				textColor : '#3c763d'
			}
		]
	});
  });


