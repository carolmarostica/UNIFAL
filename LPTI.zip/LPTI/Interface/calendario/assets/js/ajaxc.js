
$(document).ready(function() {

$('#calendar').fullCalendar({
    events:'MC.php',
 eventClick: function(calEvent, jsEvent) {

      alert('Titulo: ' + calEvent.id);
       alert('Titulo: ' + calEvent.title);
      alert('Titulo: ' + calEvent.local);
      alert('Titulo: ' + calEvent.palestrante);
      alert('Titulo: ' + calEvent.classificacao);
      alert('Titulo: ' + calEvent.descricao);
      alert('Titulo: ' + calEvent.horario);
      alert('Titulo: ' + calEvent.start);
    // mostrar qual ele selecionou
       $(this).css('border-color', 'red');

    }
});

$('#calendarioADM').fullCalendar({
 events: '../MC.php',
 eventClick: function(calEvent) {

      alert('Titulo: ' + calEvent.id);
    // mostrar qual ele selecionou
       $(this).css('border-color', 'red');

    }
 });
 });



